package com.cg.naukriregis.stepdefination;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class RedbusStep {

	private WebDriver driver;
	
	@Given("^user is on HomePage$")
	public void user_is_on_HomePage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Abhishek Bipalliwar\\Softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		
		driver.get("https://www.redbus.in");
		driver.manage().window().maximize();
		Thread.sleep(5000);
	  
	}

	@Then("^user has entered \"(.*?)\" as source$")
	public void user_has_entered_as_source(String arg1) throws Throwable {
		
		driver.findElement(By.id("src")).sendKeys("Pune");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"search\"]/div/div[1]/div/ul/li[1]")).click();
	 
	}

	@Then("^user enters \"(.*?)\" as destination$")
	public void user_enters_as_destination(String arg1) throws Throwable {
	  driver.findElement(By.id("dest")).sendKeys("Mumbai");
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("//*[@id=\"search\"]/div/div[2]/div/ul/li[1]")).click();
	}

	@Then("^user selects \"(.*?)\" as the date, \"(.*?)\" as the month-year$")
	public void user_selects_as_the_date_as_the_month_year(String arg1, String arg2) throws Throwable {
	   driver.findElement(By.xpath("//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[4]/td[2]")).click();
	}

	@When("^user presses Search buses$")
	public void user_presses_Search_buses() throws Throwable {
		driver.findElement(By.id("search_btn")).click();
		Thread.sleep(4000);
		
	    
	}

	@Then("^the user should move to booking page$")
	public void the_user_should_move_to_booking_page() throws Throwable {
	   
	}

	@When("^user selects view seats$")
	public void user_selects_view_seats() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"8194310\"]/div/div[2]/div[1]")).click();
		Thread.sleep(10000);
	}

	@Then("^boarding pt \"(.*?)\" is selected by user$")
	public void boarding_pt_is_selected_by_user(String arg1) throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"8194310\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div/div[1]/ul/li[1]/span[2]")).click();
	  
	}

	@Then("^dropping pt is selected as \"(.*?)\" by user$")
	public void dropping_pt_is_selected_as_by_user(String arg1) throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"8194310\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div/header/div[2]/h3")).click();
		driver.findElement(By.xpath("//*[@id=\"8194310\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/div[1]/div[2]/div/div/div/div[2]/ul/li[1]/span[2]")).click();
		
	   
	}

	@When("^user presses proceed$")
	public void user_presses_proceed() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"8194310\"]/div[2]/div[2]/div[2]/div[2]/div[2]/div/div[6]/button")).click();
		Thread.sleep(4000);
	   
	}

	@Then("^user enters \"(.*?)\" as name$")
	public void user_enters_as_name(String arg1) throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"seatno-04\"]")).sendKeys("Abhishek Bipalliwar");
	   
	}

	@Then("^user selects \"(.*?)\" as gender$")
	public void user_selects_as_gender(String arg1) throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[4]/div/div/div[1]/div[1]/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div/span[1]/label")).click();
	    
	}

	@Then("^user enters \"(.*?)\" as age$")
	public void user_enters_as_age(String arg1) throws Throwable {
	   driver.findElement(By.xpath("//*[@id=\"seatno-01\"]")).sendKeys("21");
	}

	@Then("^user enters \"(.*?)\" as email$")
	public void user_enters_as_email(String arg1) throws Throwable {
	   driver.findElement(By.xpath("//*[@id=\"seatno-05\"]")).sendKeys("abhi.bialliwar@gmail.com");
	}

	@Then("^user enters \"(.*?)\" as phone number$")
	public void user_enters_as_phone_number(String arg1) throws Throwable {
	  driver.findElement(By.xpath("//*[@id=\"seatno-06\"]")).sendKeys("8983104890");
	}

	@Then("^user selects \"(.*?)\" checkbox$")
	public void user_selects_checkbox(String arg1) throws Throwable {
		
	}

	@When("^user selects proceed to pay$")
	public void user_selects_proceed_to_pay() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[4]/div/div/div[2]/div[2]/input")).click();
	   
	}

	@Then("^user is directed to \"(.*?)\" Page$")
	public void user_is_directed_to_Page(String arg1) throws Throwable {
		
	 
	}

}
